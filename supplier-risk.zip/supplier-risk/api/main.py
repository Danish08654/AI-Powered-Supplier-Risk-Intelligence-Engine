import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schema import SupplierSignals, RiskAssessment

app = FastAPI(
    title="Supplier Risk Intelligence System",
    description="Predict supplier disruptions 3-6 months ahead",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Load at startup
model = xgb.XGBClassifier()
model.load_model("supplier_risk_model.json")

le_country  = joblib.load("le_country.joblib")
le_industry = joblib.load("le_industry.joblib")
le_tier     = joblib.load("le_tier.joblib")

with open("risk_metadata.json") as f:
    metadata = json.load(f)

with open("supplier_scorecard.json") as f:
    scorecard = json.load(f)

FEATURES = metadata["features"]


def safe_encode(encoder, value, known_list):
    return int(encoder.transform([value])[0]) if value in known_list else 0


def engineer_features(data: dict, country_enc, industry_enc, tier_enc) -> pd.DataFrame:
    geo_risk = {
        'China':0.72,'India':0.45,'Vietnam':0.52,'Bangladesh':0.68,
        'Mexico':0.55,'Germany':0.12,'USA':0.10,'South Korea':0.35,
        'Taiwan':0.65,'Brazil':0.48
    }
    ind_risk = {
        'Electronics':0.55,'Textiles':0.60,'Automotive':0.50,
        'Chemicals':0.65,'Food Processing':0.45,'Pharmaceuticals':0.40,
        'Steel':0.58,'Plastics':0.52
    }

    d = data.copy()
    d['country_enc']       = country_enc
    d['industry_enc']      = industry_enc
    d['tier_enc']          = tier_enc
    d['geo_risk_base']     = geo_risk.get(data['country'], 0.5)
    d['industry_risk_base']= ind_risk.get(data['industry'], 0.5)

    # Approximate rolling features with current values
    for col in ['news_sentiment_score','otd_rate','payment_delay_days',
                'port_congestion','lead_time_variance']:
        d[f'{col}_3m_avg'] = data[col]
        d[f'{col}_trend']  = 0.0

    d['risk_acceleration']    = (
        d['news_sentiment_score_trend'] +
        d['payment_delay_days_trend'] / 10 -
        d['otd_rate_trend']
    )
    d['compound_stress_signal'] = (
        int(data['news_sentiment_score'] > 0.5) +
        int(data['otd_rate'] < 0.85) +
        int(data['payment_delay_days'] > 10) +
        int(data['port_congestion'] > 6) +
        int(data['labour_unrest_signal'] == 1)
    )
    d['maturity_score'] = (
        data['years_active'] / 25 * 0.4 +
        data['n_certifications'] / 5 * 0.3 +
        (1 - data['concentration_risk']) * 0.3
    )

    return pd.DataFrame([d])[FEATURES]


def get_risk_tier(prob):
    if prob >= 0.70: return "Critical"
    if prob >= 0.50: return "High"
    if prob >= 0.30: return "Medium"
    return "Low"


def get_action(tier):
    actions = {
        "Critical": "Immediate escalation — activate backup supplier, emergency audit",
        "High":     "Weekly monitoring — dual source within 30 days",
        "Medium":   "Monthly review — request mitigation plan from supplier",
        "Low":      "Quarterly check — standard monitoring"
    }
    return actions[tier]


def get_monitoring_freq(tier):
    freq = {"Critical":"Daily","High":"Weekly","Medium":"Monthly","Low":"Quarterly"}
    return freq[tier]


@app.get("/")
def root():
    return {
        "service":   "Supplier Risk Intelligence System",
        "version":   metadata["version"],
        "model_auc": metadata["model_auc"]
    }


@app.post("/assess", response_model=RiskAssessment)
def assess_supplier(supplier: SupplierSignals):
    try:
        data         = supplier.model_dump()
        supplier_name= data.pop("supplier_name", "Unknown")

        country_enc  = safe_encode(le_country,  data['country'],
                                   metadata['countries'])
        industry_enc = safe_encode(le_industry, data['industry'],
                                   metadata['industries'])
        tier_enc     = safe_encode(le_tier,     data['supplier_tier'],
                                   metadata['supplier_tiers'])

        X = engineer_features(data, country_enc, industry_enc, tier_enc)

        # Predict
        prob = float(model.predict_proba(X)[0][1])
        tier = get_risk_tier(prob)

        # Native XGBoost contributions
        dmatrix  = xgb.DMatrix(X, feature_names=FEATURES)
        contribs = model.get_booster().predict(dmatrix, pred_contribs=True)
        vals     = contribs[0][:-1]

        pairs   = sorted(zip(FEATURES, vals), key=lambda x: abs(x[1]), reverse=True)
        drivers  = [{"factor": f, "impact": round(float(v), 4)}
                    for f, v in pairs if v > 0][:4]
        protects = [{"factor": f, "protection": round(float(abs(v)), 4)}
                    for f, v in pairs if v < 0][:3]

        return RiskAssessment(
            supplier_id=supplier.supplier_id,
            supplier_name=supplier_name,
            disruption_probability=round(prob, 4),
            risk_tier=tier,
            recommended_action=get_action(tier),
            top_risk_drivers=drivers,
            top_protective_factors=protects,
            monitoring_frequency=get_monitoring_freq(tier)
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/scorecard")
def get_scorecard():
    return scorecard[:50]


@app.get("/scorecard/critical")
def get_critical_suppliers():
    return [s for s in scorecard if s['risk_tier'] == 'Critical']


@app.get("/model/info")
def model_info():
    return metadata