from pydantic import BaseModel, Field
from typing import Optional

class SupplierSignals(BaseModel):
    supplier_id:           int
    supplier_name:         Optional[str] = "Unknown Supplier"
    country:               str
    industry:              str
    supplier_tier:         str   = Field(..., description="Tier 1 | Tier 2 | Tier 3")
    annual_revenue_m:      float = Field(..., gt=0)
    years_active:          int   = Field(..., ge=0)
    n_certifications:      int   = Field(..., ge=0)
    concentration_risk:    float = Field(..., ge=0, le=1)
    news_sentiment_score:  float = Field(..., ge=0, le=1)
    news_volume_30d:       int   = Field(..., ge=0)
    regulatory_news:       int   = Field(..., ge=0, le=1)
    labour_unrest_signal:  int   = Field(..., ge=0, le=1)
    dpo_trend:             float
    credit_change:         int   = Field(..., ge=-2, le=2)
    payment_delay_days:    float = Field(..., ge=0)
    revenue_growth:        float
    otd_rate:              float = Field(..., ge=0, le=1)
    lead_time_variance:    float = Field(..., ge=0)
    port_congestion:       float = Field(..., ge=0, le=10)
    shipping_cost_change:  float
    climate_severity:      float = Field(..., ge=0)
    nat_disaster_flag:     int   = Field(..., ge=0, le=1)

class RiskAssessment(BaseModel):
    supplier_id:           int
    supplier_name:         str
    disruption_probability:float
    risk_tier:             str
    recommended_action:    str
    top_risk_drivers:      list
    top_protective_factors:list
    monitoring_frequency:  str